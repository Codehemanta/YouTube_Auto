//YouTube Auto by @thegayen - https://github.com/Codehemanta/YouTube_Auto/ - @YoutubeAuto
//License - https://github.com/Codehemanta/YouTube_Auto/blob/main/LICENSE ( JS: Mozilla Public License 2.0 )
console.log("ok")
alert("hd") 
    var a = new Promise(function(resolve, reject){
            window.Storage.sync.get({"enabled": true}, function(options){
              resolve(options.enabled);
          })
      });

    const enabled = await a;
    console.log(enabled + " enabled");