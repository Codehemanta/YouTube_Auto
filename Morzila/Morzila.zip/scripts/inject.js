//YouTube Auto by @thegayen - https://github.com/Codehemanta/YouTube_Auto/ - @YoutubeAuto
//License - https://github.com/Codehemanta/YouTube_Auto/blob/main/LICENSE ( JS: Mozilla Public License 2.0 )
console.log("ok")
alert("hd") 
    chrome.storage.sync.set({'foo': 'hello', 'bar': 'hi'}, function() {
      console.log('Settings saved');
    });